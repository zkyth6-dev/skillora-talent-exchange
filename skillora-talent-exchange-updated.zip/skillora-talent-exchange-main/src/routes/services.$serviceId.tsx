import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { BadgeCheck, Check, Clock, Languages, MapPin, SearchX, Star } from "lucide-react";
import { PreviewBadge } from "@/components/marketplace/PreviewBadge";
import { ProviderAvatar } from "@/components/marketplace/ProviderAvatar";
import { ServiceCard } from "@/components/marketplace/ServiceCard";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Button } from "@/components/ui/button";
import {
  getPreviewProvider,
  getPreviewService,
  getPreviewServiceDetail,
  PREVIEW_SERVICES,
} from "@/data/preview-services";
import { calculateOrderFees } from "@/lib/fees";
import {
  countryName,
  formatList,
  formatMoney,
  formatNumber,
  formatPercent,
  languageName,
} from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import { relatedServices } from "@/lib/related-services";

export const Route = createFileRoute("/services/$serviceId")({
  loader: ({ params }) => {
    const service = getPreviewService(params.serviceId);
    if (!service) throw notFound();
    return { service };
  },
  head: ({ loaderData }) => {
    const service = loaderData?.service;
    const title = service ? `${service.title} — Skillora` : "Service not found — Skillora";
    const description = service
      ? (getPreviewServiceDetail(service.id)?.summary ?? "A digital service on Skillora.")
      : "This service could not be found on Skillora.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        // Sample listings must not be indexed. Remove once services come from the database.
        { name: "robots", content: "noindex" },
      ],
    };
  },
  notFoundComponent: ServiceNotFound,
  component: ServiceDetailPage,
});

function ServiceNotFound() {
  const { m } = useI18n();
  return (
    <div className="container-page flex flex-col items-center py-24 text-center">
      <span className="flex size-14 items-center justify-center rounded-2xl bg-accent text-primary">
        <SearchX className="size-7" aria-hidden="true" />
      </span>
      <h1 className="mt-5 text-2xl font-bold">{m.detail.notFoundTitle}</h1>
      <p className="mt-2 max-w-sm text-sm text-muted-foreground">{m.detail.notFoundBody}</p>
      <Button asChild className="mt-6">
        <Link to="/services">{m.nav.explore}</Link>
      </Button>
    </div>
  );
}

function ServiceDetailPage() {
  const { service } = Route.useLoaderData();
  const { m, intlLocale } = useI18n();

  const provider = getPreviewProvider(service.providerId);
  const detail = getPreviewServiceDetail(service.id);
  const related = relatedServices(service, PREVIEW_SERVICES, 3);
  const fees = calculateOrderFees(service.priceFromMinor);
  const money = (minor: number) => formatMoney(minor, service.currency, intlLocale);

  return (
    <div className="bg-gradient-soft">
      <div className="container-page py-8 md:py-12">
        <PreviewBadge withNote className="mb-5" />

        <Breadcrumb aria-label={m.detail.breadcrumb} className="mb-6">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link to="/services">{m.nav.explore}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link to="/services" search={{ category: service.category }}>
                  {m.categories.labels[service.category]}
                </Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <div className="grid gap-x-10 gap-y-8 lg:grid-cols-[minmax(0,1fr)_22rem]">
          <div className="lg:col-start-1">
            <h1 className="max-w-3xl text-3xl font-extrabold leading-tight sm:text-4xl">
              {service.title}
            </h1>

            <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-muted-foreground">
              {provider && (
                <span className="inline-flex items-center gap-2.5 text-foreground">
                  <ProviderAvatar name={provider.name} className="size-8 text-[11px]" />
                  <span className="font-semibold">{provider.name}</span>
                  {provider.verified && (
                    <BadgeCheck className="size-4 shrink-0 text-primary" aria-label={m.service.verified} />
                  )}
                </span>
              )}
              <span className="inline-flex items-center gap-1">
                <Star className="size-4 fill-warning text-warning" aria-hidden="true" />
                <span className="font-semibold text-foreground">
                  {formatNumber(service.rating, intlLocale, {
                    minimumFractionDigits: 1,
                    maximumFractionDigits: 1,
                  })}
                </span>
                <span className="sr-only">/5,</span>
                <span>({m.service.reviews(formatNumber(service.reviewCount, intlLocale))})</span>
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Clock className="size-4" aria-hidden="true" />
                {m.service.delivery(service.deliveryDays)}
              </span>
            </div>

            <div className="mt-6 overflow-hidden rounded-2xl border bg-muted shadow-card">
              <img
                src={service.cover}
                alt=""
                width={1024}
                height={768}
                fetchPriority="high"
                decoding="async"
                className="aspect-[16/10] w-full object-cover"
              />
            </div>
          </div>

          <aside className="lg:col-start-2 lg:row-span-2 lg:row-start-1">
            <div className="rounded-2xl border bg-card p-5 text-card-foreground shadow-card lg:sticky lg:top-24">
              <p className="text-sm text-muted-foreground">{m.service.from}</p>
              <p className="text-3xl font-extrabold">{money(service.priceFromMinor)}</p>
              <p className="mt-3 inline-flex items-center gap-1.5 text-sm text-muted-foreground">
                <Clock className="size-4" aria-hidden="true" />
                {m.service.delivery(service.deliveryDays)}
              </p>

              <Button size="lg" className="mt-5 w-full" disabled aria-describedby="order-unavailable">
                {m.detail.orderCta}
              </Button>
              <p id="order-unavailable" className="mt-2 text-xs text-muted-foreground">
                {m.detail.orderUnavailable}
              </p>

              <div className="mt-5 border-t pt-4">
                <h2 className="text-sm font-bold">{m.detail.feeHeading}</h2>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  {m.benefits.feeExample(money(fees.subtotalMinor))}
                </p>
                <dl className="mt-3 space-y-2 text-sm">
                  <div className="flex items-baseline justify-between gap-4">
                    <dt className="text-muted-foreground">{m.benefits.feeOrder}</dt>
                    <dd className="font-semibold">{money(fees.subtotalMinor)}</dd>
                  </div>
                  <div className="flex items-baseline justify-between gap-4">
                    <dt className="text-muted-foreground">
                      {m.benefits.feeCommission(formatPercent(fees.rate, intlLocale))}
                    </dt>
                    <dd className="font-semibold">− {money(fees.commissionMinor)}</dd>
                  </div>
                  <div className="flex items-baseline justify-between gap-4 border-t pt-2">
                    <dt className="font-semibold">{m.benefits.feeNet}</dt>
                    <dd className="font-bold">{money(fees.providerNetMinor)}</dd>
                  </div>
                </dl>
                <p className="mt-3 text-xs text-muted-foreground">{m.detail.feeNote}</p>
              </div>

              <Button variant="outline" asChild className="mt-5 w-full">
                <Link to="/services">{m.detail.back}</Link>
              </Button>
            </div>
          </aside>

          <div className="space-y-10 lg:col-start-1">
            {detail && (
              <>
                <section aria-labelledby="about-heading">
                  <h2 id="about-heading" className="text-xl font-bold">
                    {m.detail.about}
                  </h2>
                  <p className="mt-3 max-w-prose leading-relaxed text-muted-foreground">
                    {detail.summary}
                  </p>
                </section>

                <section aria-labelledby="included-heading">
                  <h2 id="included-heading" className="text-xl font-bold">
                    {m.detail.included}
                  </h2>
                  <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                    {detail.includes.map((item) => (
                      <li key={item} className="flex items-start gap-2.5 text-sm">
                        <Check className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </section>
              </>
            )}

            {provider && (
              <section aria-labelledby="provider-heading">
                <h2 id="provider-heading" className="text-xl font-bold">
                  {m.detail.provider}
                </h2>
                <div className="mt-4 flex items-start gap-4 rounded-2xl border bg-card p-5 shadow-card">
                  <ProviderAvatar name={provider.name} className="size-12 text-sm" />
                  <div className="min-w-0">
                    <p className="flex items-center gap-1.5 font-semibold">
                      {provider.name}
                      {provider.verified && (
                        <BadgeCheck className="size-4 shrink-0 text-primary" aria-label={m.service.verified} />
                      )}
                    </p>
                    <p className="text-sm text-muted-foreground">{provider.headline}</p>
                    <dl className="mt-3 space-y-1.5 text-sm">
                      <div className="flex items-center gap-2">
                        <dt className="sr-only">{m.detail.basedIn}</dt>
                        <MapPin className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                        <dd>{countryName(provider.country, intlLocale)}</dd>
                      </div>
                      <div className="flex items-center gap-2">
                        <dt className="sr-only">{m.freelancers.speaks}</dt>
                        <Languages className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                        <dd>
                          {formatList(
                            provider.languages.map((l) => languageName(l, intlLocale)),
                            intlLocale,
                          )}
                        </dd>
                      </div>
                    </dl>
                  </div>
                </div>
              </section>
            )}
          </div>
        </div>

        {related.length > 0 && (
          <section aria-labelledby="related-heading" className="mt-14">
            <h2 id="related-heading" className="text-xl font-bold">
              {m.detail.related}
            </h2>
            <div className="mt-5 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((s) => (
                <ServiceCard key={s.id} service={s} provider={getPreviewProvider(s.providerId)} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
