import { describe, expect, it } from "vitest";
import {
  getPreviewService,
  getPreviewServiceDetail,
  PREVIEW_SERVICES,
} from "@/data/preview-services";
import { calculateOrderFees } from "@/lib/fees";
import { formatList } from "@/lib/format";
import { relatedServices } from "@/lib/related-services";

describe("service detail data", () => {
  it("finds a service by id and returns undefined for unknown ids", () => {
    expect(getPreviewService("s1")?.id).toBe("s1");
    expect(getPreviewService("does-not-exist")).toBeUndefined();
  });

  it("has detail copy for every preview service", () => {
    for (const s of PREVIEW_SERVICES) {
      const detail = getPreviewServiceDetail(s.id);
      expect(detail, `missing detail for ${s.id}`).toBeDefined();
      expect(detail?.summary.length).toBeGreaterThan(20);
      expect(detail?.includes.length).toBeGreaterThanOrEqual(3);
    }
  });

  it("shows the 5% fee on the starting price without float drift", () => {
    const s = getPreviewService("s1")!;
    const f = calculateOrderFees(s.priceFromMinor);
    expect(f.commissionMinor).toBe(900);
    expect(f.providerNetMinor).toBe(17100);
  });
});

describe("relatedServices", () => {
  const all = PREVIEW_SERVICES;

  it("never includes the current service and respects the limit", () => {
    const current = getPreviewService("s1")!;
    const result = relatedServices(current, all, 3);
    expect(result.map((s) => s.id)).not.toContain("s1");
    expect(result.length).toBeLessThanOrEqual(3);
  });

  it("ranks same category and same provider above same category only", () => {
    // s1 and s9 share category (logo-branding) and provider (p1).
    expect(relatedServices(getPreviewService("s1")!, all, 3)[0]?.id).toBe("s9");
  });

  it("returns an empty list when nothing relates", () => {
    expect(relatedServices(getPreviewService("s4")!, all)).toEqual([]);
  });
});

describe("formatList", () => {
  it("joins items with a locale-aware conjunction", () => {
    expect(formatList(["English", "French"], "en-US")).toBe("English and French");
    expect(formatList(["Inggris", "Prancis"], "id-ID")).toContain("dan");
  });
});
