interface RelatedKey {
  id: string;
  category: string;
  providerId: string;
}

/**
 * Picks services related to `current`: same category ranks above same provider,
 * both together rank highest. Ties keep their original order. Returns [] when nothing relates.
 */
export function relatedServices<T extends RelatedKey>(
  current: T,
  all: readonly T[],
  limit = 3,
): T[] {
  const score = (s: T) =>
    (s.category === current.category ? 2 : 0) + (s.providerId === current.providerId ? 1 : 0);

  return all
    .map((s, index) => ({ s, index, score: score(s) }))
    .filter(({ s, score: sc }) => s.id !== current.id && sc > 0)
    .sort((a, b) => b.score - a.score || a.index - b.index)
    .slice(0, Math.max(0, limit))
    .map(({ s }) => s);
}
