# Proguard rules for Skillora
